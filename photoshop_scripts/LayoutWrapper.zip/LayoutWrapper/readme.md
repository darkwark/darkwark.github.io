# Layout Wrapper Readme

## Installation
Move folder ``LayoutWrapper`` to the ``Photoshop folder/Presets/Scripts/``   
Restart Photoshop. Script can be accessed from ``File→Scripts→[KAM] LayoutWrapper``

## How it works
Script makes a snapshot of the current document and places it into Safari browser window in new document. Title of the window and text in address bar will be the same as original document's name. But you can change it to whatever you want—text layers are editable. You can change favicon and background color too
Take a notice, that **minimum size of the document is 160×1**
[More info](http://darkwark.com)  
  
  
  
  
Created by [Kamil Khadeyev](http://twitter.com/darkwark) © 2013
