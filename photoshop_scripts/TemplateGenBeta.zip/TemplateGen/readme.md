# TemplateGen Beta

Script for dealing with templates in Adobe Photoshop.
Created by Kamil Khadeyev © 2013

[Read more](http://blog.kam88.com/en/templategen-beta-script.html)